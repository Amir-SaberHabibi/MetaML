import streamlit as st
import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import streamlit as st


# Load an image
# st.image("C:/Users/L5/OneDrive/Documents/GitHub/MetaML/src/images/logo.png", use_column_width=True)'
st.set_page_config(page_title="Replicate Image Generator",
                   page_icon=":car:",
                   layout="centered")

with open(r"C:\Users\L5\OneDrive\Documents\GitHub\MetaML\src\ui\sidebar.md", "r") as sidebar_file:
    sidebar_content = sidebar_file.read()

with open(r"C:\Users\L5\OneDrive\Documents\GitHub\MetaML\src\ui\styles.md", "r") as styles_file:
    styles_content = styles_file.read()

st.sidebar.markdown(sidebar_content)
st.write(styles_content, unsafe_allow_html=True)


gradient_text_html = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Lexend:wght@400;700&display=swap');

.gradient-text {
    font-family: 'Lexend', sans-serif;
    font-weight: bold;
    background: -webkit-linear-gradient(left, white, cyan, magenta, yellow);
    background: linear-gradient(to right, white, cyan, magenta, yellow);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    display: inline;
    font-size: 10em;
    background-size: 300% 300%;
    animation: float 3s ease-in-out infinite, gradient 5s ease infinite;
}

@keyframes float {
    0%, 100% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(-10px);
    }
}

@keyframes gradient {
    0% {
        background-position: 0% 50%;
    }
    50% {
        background-position: 100% 50%;
    }
    100% {
        background-position: 0% 50%;
    }
}
</style>
<div class="gradient-text">MetaML</div>
"""

st.markdown(gradient_text_html, unsafe_allow_html=True)
# Define tabs
tab1, tab2, tab3, tab4, tab5 = st.tabs(["Home", "Backpropagation", "Genetic Algorithm", "PSO", "Comparison"])

# Home tab
with tab1:
    st.title('Welcome to MetaheuristicML!')
    st.write("""
    A project focused on optimizing machine learning models using advanced metaheuristic techniques.
    Our algorithms are designed to enhance the efficiency and performance of your machine learning tasks through innovative optimization strategies.
    Explore and compare different optimization methods to find the best fit for your models.
    """)
    exec(open("sidebar.py").read())



# Backpropagation tab
with tab2:
    st.header("Backpropagation Algorithm")
    st.write("""
    **Features of the Backpropagation Algorithm:**

    1. **Initialization**:
       - Weights and biases are initialized randomly.
       - The learning rate and the number of epochs are set as hyperparameters.

    2. **Forward Propagation**:
       - Inputs are passed through the network to obtain outputs using the sigmoid activation function.
       - The output of each layer is calculated and used as input for the next layer.

    3. **Error Calculation**:
       - The error is calculated as the difference between the predicted outputs and the actual XOR outputs.
       - The Mean Squared Error (MSE) is used as the error metric.

    4. **Backward Propagation**:
       - The error is propagated back through the network.
       - The weights and biases are adjusted to minimize the error using the gradient of the error.

    5. **Iteration**:
       - The process of forward propagation, error calculation, and backward propagation is repeated for a specified number of epochs.

    6. **Result**:
       - The algorithm returns the final weights and biases, and the corresponding error value.
    """)
    exec(open("BP.py").read())

with tab4:
    st.write("""
    **Features of the PSO Algorithm:**
    
    1. **Initialization**: 
       - A population of particles is initialized, each representing a potential solution (weights and biases for the neural network).
       - Each particle has a position in the search space and a velocity.

    2. **Evaluation**:
       - Each particle's position (solution) is evaluated using the Mean Squared Error (MSE) between the predicted outputs and the actual XOR outputs.

    3. **Personal and Global Bests**:
       - The algorithm keeps track of each particle's personal best position (the position that yielded the lowest error for that particle) and the global best position (the position that yielded the lowest error among all particles).

    4. **Update Velocities and Positions**:
       - In each iteration, the velocity of each particle is updated based on three components:
         - `Inertia`: The previous velocity, scaled by the inertia weight.
         - `Cognitive` Component: Steers the particle towards its personal best position.
         - `Social Component`: Steers the particle towards the global best position.
       - The particle's position is then updated by adding the new velocity to the current position.

    5. **Iteration**:
       - The process of evaluating, updating velocities, and updating positions is repeated for a specified number of generations.
       - The algorithm converges when the global best position no longer changes significantly or when the maximum number of generations is reached.

    6. **Result**:
       - The algorithm returns the global best position (the set of weights and biases that minimize the error) and the corresponding error value.
    """)
    exec(open("PSO.py").read())


